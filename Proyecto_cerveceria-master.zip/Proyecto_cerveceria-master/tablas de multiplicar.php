<?php
$multiplicador=20;
$multiplicado=0;
for($multiplicado=0;$multiplicado<=$multiplicador;$multiplicado++)
{
    $multiplicador=$multiplicado*$multiplicador;
    echo $multiplicador;

}

